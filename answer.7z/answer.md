# 第3次練習-練習-PC3
>
>學號：111104105
><br />
>姓名：陳郁升
><br />
>作業撰寫時間：20 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2023/11/24
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x] 說明內容
- [x] 個人認為完成作業須具備觀念

## 說明程式與內容
FinalPorject112-1的網址  
https://github.com/Yusheng0728/FinalPorject112-1  
我的分支(bb)  
https://github.com/Yusheng0728/FinalPorject112-1/tree/bb  
  
  
1.建立一個倉庫(FinalPorject112-1)  
2.邀請組員進倉庫  
3.在vscode內建立自己的分支並切換分支  
4.把分支推上github  
## 個人認為完成作業須具備觀念

需要了解github內的操作，如何邀請組員共用同個repository，建立分支和順利地切換分支在之前的練習就已經做過了，如果有複習過應該都會做。